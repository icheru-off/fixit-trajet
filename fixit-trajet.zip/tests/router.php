<?php
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('~^/(data|inc)(/|$)~', $uri)) { http_response_code(403); echo 'Forbidden'; return true; }
if (preg_match('~^/s/([A-Za-z0-9_-]{16,40})/?$~', $uri, $m)) { $_GET['k'] = $m[1]; $_SERVER['SCRIPT_NAME'] = '/s.php'; require __DIR__ . '/s.php'; return true; }

return false;
