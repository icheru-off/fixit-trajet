#!/usr/bin/env bash
# Récupère les bibliothèques volumineuses (MapLibre + polices) depuis npm, pour garder le dépôt léger.
set -euo pipefail
T=$(mktemp -d); cd "$T"
npm pack -s maplibre-gl@5.24.1 @fontsource/bricolage-grotesque@5 @fontsource/ibm-plex-sans@5 @fontsource/ibm-plex-mono@5 >/dev/null
for f in *.tgz; do mkdir -p "${f%.tgz}" && tar xzf "$f" -C "${f%.tgz}"; done
cd - >/dev/null
V=site/assets/vendor; F=site/assets/fonts; mkdir -p $V $F
cp "$T"/maplibre-gl-*/package/dist/{maplibre-gl-csp.js,maplibre-gl-csp-worker.js,maplibre-gl.css} $V/
cp "$T"/maplibre-gl-*/package/LICENSE.txt $V/MAPLIBRE-LICENSE.txt
cp "$T"/fontsource-bricolage-grotesque-*/package/files/bricolage-grotesque-latin-{700,800}-normal.woff2 $F/
cp "$T"/fontsource-ibm-plex-sans-*/package/files/ibm-plex-sans-latin-{400,500,600,700}-normal.woff2 $F/
cp "$T"/fontsource-ibm-plex-mono-*/package/files/ibm-plex-mono-latin-600-normal.woff2 $F/
ls -l $V $F
