<?php
/**
 * Géométrie + appels aux services gratuits (itinéraire, géocodage).
 *  - Itinéraire : OSRM (router.project-osrm.org) puis serveur OSRM de FOSSGIS en secours.
 *  - Trafic temps réel (option) : TomTom Routing API avec une clé gratuite.
 *  - Adresses : API Géoplateforme de l'IGN (ex-API Adresse), gratuite et sans clé.
 */
declare(strict_types=1);

const OSRM_PRIMARY = 'https://router.project-osrm.org';
const OSRM_FALLBACK = 'https://routing.openstreetmap.de/routed-car';
const GEOCODE_URL = 'https://data.geopf.fr/geocodage/search';
const TOMTOM_MONTHLY_CAP = 18000; // offre gratuite TomTom : 20 000 calculs / mois → marge de sécurité

function haversine(float $lat1, float $lon1, float $lat2, float $lon2): float
{
    $r = 6371000.0;
    $p1 = deg2rad($lat1);
    $p2 = deg2rad($lat2);
    $dp = $p2 - $p1;
    $dl = deg2rad($lon2 - $lon1);
    $a = sin($dp / 2) ** 2 + cos($p1) * cos($p2) * sin($dl / 2) ** 2;
    return 2 * $r * asin(min(1.0, sqrt($a)));
}

/** Distance (m) d'un point à une polyligne [[lon,lat],...] — projection équirectangulaire locale. */
function dist_to_polyline(float $lat, float $lon, array $coords): float
{
    $n = count($coords);
    if ($n === 0) return INF;
    $kx = 111320.0 * cos(deg2rad($lat));
    $ky = 110540.0;
    $best = INF;
    for ($i = 0; $i < $n; $i++) {
        $ax = ($coords[$i][0] - $lon) * $kx;
        $ay = ($coords[$i][1] - $lat) * $ky;
        if ($i === $n - 1) {
            $best = min($best, hypot($ax, $ay));
            break;
        }
        $bx = ($coords[$i + 1][0] - $lon) * $kx;
        $by = ($coords[$i + 1][1] - $lat) * $ky;
        $dx = $bx - $ax;
        $dy = $by - $ay;
        $len2 = $dx * $dx + $dy * $dy;
        $t = $len2 > 0 ? max(0, min(1, -($ax * $dx + $ay * $dy) / $len2)) : 0;
        $best = min($best, hypot($ax + $t * $dx, $ay + $t * $dy));
    }
    return $best;
}

/** Réduit une polyligne à ~$max points (garde le premier et le dernier). */
function simplify_coords(array $coords, int $max = 500): array
{
    $n = count($coords);
    if ($n <= $max) return $coords;
    $step = $n / ($max - 1);
    $out = [];
    for ($i = 0; $i < $max - 1; $i++) $out[] = $coords[(int)floor($i * $step)];
    $out[] = $coords[$n - 1];
    return $out;
}

function round_coords(array $coords): array
{
    return array_map(fn($c) => [round((float)$c[0], 5), round((float)$c[1], 5)], $coords);
}

/* ───────────── Client HTTP ───────────── */

function http_get_json(string $url, int $timeout = 7): ?array
{
    $ua = 'FixIT-Suivi/' . APP_VERSION . ' (+https://fixit-service.fr)';
    $referer = function_exists('cfg') ? (string)cfg('base_url', 'https://fixit-service.fr') : 'https://fixit-service.fr';
    $body = null;
    $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_REFERER => $referer,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
            CURLOPT_ENCODING => '',
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
    } elseif (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http' => [
            'timeout' => $timeout, 'ignore_errors' => true,
            'header' => "User-Agent: $ua\r\nReferer: $referer\r\nAccept: application/json\r\n",
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        $code = 200;
        foreach ($http_response_header ?? [] as $hline) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})~', $hline, $m)) $code = (int)$m[1];
        }
    }
    if (!is_string($body) || $code < 200 || $code >= 300) return null;
    $j = json_decode($body, true);
    return is_array($j) ? $j : null;
}

/* ───────────── Itinéraires ───────────── */

/**
 * Calcule l'itinéraire voiture. Retourne
 * ['provider','traffic'=>bool,'raw_s','dist_m','coords'=>[[lon,lat]...],'delay_s'] ou null.
 */
function compute_route(float $flat, float $flon, float $tlat, float $tlon): ?array
{
    $key = trim((string)setting('tomtom_key', ''));
    if ($key !== '' && tomtom_quota_ok()) {
        $r = route_tomtom($key, $flat, $flon, $tlat, $tlon);
        if ($r) return $r;
    }
    $primary = trim((string)setting('osrm_url', OSRM_PRIMARY)) ?: OSRM_PRIMARY;
    foreach (array_unique([$primary, OSRM_FALLBACK]) as $base) {
        $r = route_osrm($base, $flat, $flon, $tlat, $tlon);
        if ($r) return $r;
    }
    return null;
}

function route_osrm(string $base, float $flat, float $flon, float $tlat, float $tlon): ?array
{
    $url = rtrim($base, '/') . sprintf(
        '/route/v1/driving/%.6F,%.6F;%.6F,%.6F?overview=full&geometries=geojson&steps=false&alternatives=false',
        $flon, $flat, $tlon, $tlat
    );
    $j = http_get_json($url);
    if (!$j || ($j['code'] ?? '') !== 'Ok' || empty($j['routes'][0])) return null;
    $r = $j['routes'][0];
    $coords = $r['geometry']['coordinates'] ?? [];
    if (!is_array($coords) || count($coords) < 2) return null;
    return [
        'provider' => 'osrm',
        'traffic' => false,
        'raw_s' => (float)$r['duration'],
        'dist_m' => (float)$r['distance'],
        'delay_s' => 0.0,
        'coords' => round_coords(simplify_coords($coords)),
    ];
}

function tomtom_quota_ok(): bool
{
    $month = date('Y-m');
    if (setting('tt_month') !== $month) return true;
    return (int)setting('tt_count', 0) < TOMTOM_MONTHLY_CAP;
}

function tomtom_count(): void
{
    $month = date('Y-m');
    if (setting('tt_month') !== $month) {
        set_setting('tt_month', $month);
        set_setting('tt_count', 1);
    } else {
        set_setting('tt_count', (int)setting('tt_count', 0) + 1);
    }
}

function route_tomtom(string $key, float $flat, float $flon, float $tlat, float $tlon): ?array
{
    $url = sprintf(
        'https://api.tomtom.com/routing/1/calculateRoute/%.6F,%.6F:%.6F,%.6F/json?key=%s&traffic=true&travelMode=car&routeType=fastest&computeTravelTimeFor=all&language=fr-FR',
        $flat, $flon, $tlat, $tlon, rawurlencode($key)
    );
    tomtom_count();
    $j = http_get_json($url);
    if (!$j || empty($j['routes'][0]['summary'])) return null;
    $r = $j['routes'][0];
    $coords = [];
    foreach ($r['legs'] ?? [] as $leg) {
        foreach ($leg['points'] ?? [] as $p) $coords[] = [(float)$p['longitude'], (float)$p['latitude']];
    }
    if (count($coords) < 2) $coords = [[$flon, $flat], [$tlon, $tlat]];
    $s = $r['summary'];
    return [
        'provider' => 'tomtom',
        'traffic' => true,
        'raw_s' => (float)$s['travelTimeInSeconds'],
        'dist_m' => (float)$s['lengthInMeters'],
        'delay_s' => (float)($s['trafficDelayInSeconds'] ?? 0),
        'coords' => round_coords(simplify_coords($coords)),
    ];
}

/* ───────────── Géocodage (IGN Géoplateforme) ───────────── */

function geocode_search(string $q, int $limit = 5): array
{
    $q = trim($q);
    if (mb_strlen($q) < 3) return [];
    $base = trim((string)setting('geocode_url', GEOCODE_URL)) ?: GEOCODE_URL;
    $j = http_get_json($base . '?' . http_build_query(['q' => $q, 'limit' => $limit, 'index' => 'address']));
    $out = [];
    foreach ($j['features'] ?? [] as $f) {
        $c = $f['geometry']['coordinates'] ?? null;
        if (!$c) continue;
        $out[] = [
            'label' => (string)($f['properties']['label'] ?? ''),
            'context' => (string)($f['properties']['context'] ?? ''),
            'lon' => (float)$c[0],
            'lat' => (float)$c[1],
        ];
    }
    return $out;
}
