<?php
/**
 * FixIT Suivi — noyau commun (config, base SQLite, sécurité, helpers).
 */
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
define('DATA_DIR', APP_ROOT . '/data');
define('CONFIG_FILE', DATA_DIR . '/config.php');
define('APP_VERSION', '1.0.0');

date_default_timezone_set('Europe/Paris');
mb_internal_encoding('UTF-8');
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/geo.php';
require_once __DIR__ . '/eta.php';
require_once __DIR__ . '/messages.php';
require_once __DIR__ . '/layout.php';

/* ───────────── Configuration ───────────── */

function is_installed(): bool
{
    return is_file(CONFIG_FILE);
}

function cfg(string $key, $default = null)
{
    if (!isset($GLOBALS['__fixit_cfg'])) {
        $GLOBALS['__fixit_cfg'] = is_installed() ? (require CONFIG_FILE) : [];
    }
    return $GLOBALS['__fixit_cfg'][$key] ?? $default;
}

/** Recharge la configuration et la connexion (utilisé juste après l'installation). */
function cfg_reset(): void
{
    unset($GLOBALS['__fixit_cfg'], $GLOBALS['__fixit_db'], $GLOBALS['__fixit_settings']);
}

/* ───────────── Base de données ───────────── */

function db(): PDO
{
    if (isset($GLOBALS['__fixit_db'])) return $GLOBALS['__fixit_db'];
    if (!is_installed()) throw new RuntimeException('not installed');
    $file = DATA_DIR . '/' . cfg('db_file', 'suivi.sqlite');
    $pdo = new PDO('sqlite:' . $file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA foreign_keys = ON');
    migrate($pdo);
    return $GLOBALS['__fixit_db'] = $pdo;
}

function migrate(PDO $pdo): void
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)');
    $v = (int)($pdo->query("SELECT v FROM settings WHERE k='schema'")->fetchColumn() ?: 0);
    if ($v >= 1) return;
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS interventions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT NOT NULL UNIQUE,
            client_name TEXT NOT NULL,
            client_phone TEXT, client_email TEXT,
            address TEXT NOT NULL, address_extra TEXT,
            lat REAL, lon REAL,
            scheduled_at INTEGER NOT NULL,
            duration_min INTEGER DEFAULT 60,
            services TEXT, device TEXT, problem TEXT, price_note TEXT, notes TEXT,
            status TEXT NOT NULL DEFAULT 'planned',
            trip_started_at INTEGER, move_started_at INTEGER,
            origin_lat REAL, origin_lon REAL,
            base_raw_s REAL, base_at INTEGER, base_provider TEXT,
            route_json TEXT, route_v INTEGER NOT NULL DEFAULT 0, route_at INTEGER,
            route_raw_s REAL, route_dist_m REAL, route_provider TEXT, route_traffic INTEGER DEFAULT 0, route_hist TEXT,
            eta_at INTEGER, eta_low INTEGER, eta_high INTEGER, eta_factor REAL, eta_updated INTEGER, first_eta_at INTEGER, eta_jam INTEGER DEFAULT 0,
            pos_lat REAL, pos_lon REAL, pos_acc REAL, pos_speed REAL, pos_heading REAL, pos_ts INTEGER, pos_source TEXT,
            near_count INTEGER NOT NULL DEFAULT 0,
            arrived_at INTEGER, started_at INTEGER, done_at INTEGER,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS iv_status ON interventions(status);
        CREATE INDEX IF NOT EXISTS iv_sched ON interventions(scheduled_at);
        CREATE TABLE IF NOT EXISTS positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            iv_id INTEGER NOT NULL REFERENCES interventions(id) ON DELETE CASCADE,
            lat REAL NOT NULL, lon REAL NOT NULL, acc REAL, speed REAL, heading REAL,
            ts INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS pos_iv ON positions(iv_id, ts);
        CREATE TABLE IF NOT EXISTS login_fails (ip TEXT NOT NULL, ts INTEGER NOT NULL);
    ");
    $pdo->exec("INSERT OR REPLACE INTO settings(k,v) VALUES('schema','1')");
}

function setting(string $k, $default = null)
{
    if (!is_installed()) return $default;
    $cache = &$GLOBALS['__fixit_settings'];
    if (!is_array($cache)) $cache = [];
    if (array_key_exists($k, $cache)) return $cache[$k] ?? $default;
    $st = db()->prepare('SELECT v FROM settings WHERE k = ?');
    $st->execute([$k]);
    $v = $st->fetchColumn();
    $cache[$k] = ($v === false ? null : $v);
    return $cache[$k] ?? $default;
}

function set_setting(string $k, $v): void
{
    db()->prepare('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')
        ->execute([$k, $v === null ? null : (string)$v]);
    $GLOBALS['__fixit_settings'][$k] = $v === null ? null : (string)$v;
}

/* ───────────── HTTP / sécurité ───────────── */

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
}

function detect_base_url(): string
{
    $scheme = is_https() ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $dir = rtrim(dirname($script), '/');
    // remonte jusqu'à la racine de l'appli (admin/, api/ → racine)
    foreach (['/admin', '/api'] as $sub) {
        if (str_ends_with($dir, $sub)) $dir = substr($dir, 0, -strlen($sub));
    }
    return $scheme . '://' . $host . $dir;
}

function base_url(string $path = ''): string
{
    $b = rtrim((string)cfg('base_url', detect_base_url()), '/');
    return $b . '/' . ltrim($path, '/');
}

/** Chemin relatif de l'appli (pour les cookies). */
function base_path(): string
{
    $p = parse_url(base_url(), PHP_URL_PATH) ?: '/';
    return rtrim($p, '/') . '/';
}

function client_link(string $token): string
{
    return base_url('s/' . $token);
}

function send_security_headers(bool $map = false): void
{
    header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: geolocation=(self), camera=(), microphone=()');
    $tiles = map_origin();
    $csp = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self';"
        . " img-src 'self' data: blob:" . ($tiles ? " $tiles" : '') . ';'
        . " connect-src 'self' https://data.geopf.fr" . ($tiles ? " $tiles" : '') . ';'
        . " worker-src 'self' blob:; child-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";
    header('Content-Security-Policy: ' . $csp);
}

function map_style_url(): string
{
    $s = (string)setting('map_style', 'positron');
    if (preg_match('~^(https?://|/)~', $s)) return $s;
    $allowed = ['positron', 'liberty', 'bright'];
    return 'https://tiles.openfreemap.org/styles/' . (in_array($s, $allowed, true) ? $s : 'positron');
}

function map_origin(): string
{
    $u = map_style_url();
    if ($u[0] === '/') return '';
    $p = parse_url($u);
    return ($p['scheme'] ?? 'https') . '://' . ($p['host'] ?? '');
}

function no_cache(): void
{
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function json_out($data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    no_cache();
    header('X-Robots-Tag: noindex, nofollow');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function h($s): string
{
    return htmlspecialchars((string)($s ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function client_ip(): string
{
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function random_token(int $bytes = 16): string
{
    return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
}

/* ───────────── Session / authentification ───────────── */

function start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('FIXITSUIVI');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => base_path(),
        'secure' => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function remember_sig(int $exp): string
{
    return hash_hmac('sha256', 'remember|' . $exp . '|' . setting('auth_epoch', '1'), (string)cfg('secret'));
}

function set_remember_cookie(): void
{
    $exp = time() + 60 * 86400;
    setcookie('FIXITSUIVI_R', $exp . '.' . remember_sig($exp), [
        'expires' => $exp, 'path' => base_path(), 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax',
    ]);
}

function is_admin(): bool
{
    start_session();
    if (!empty($_SESSION['admin'])) return true;
    $c = $_COOKIE['FIXITSUIVI_R'] ?? '';
    if (preg_match('/^(\d{10})\.([a-f0-9]{64})$/', $c, $m) && (int)$m[1] > time()
        && hash_equals(remember_sig((int)$m[1]), $m[2])) {
        session_regenerate_id(true);
        $_SESSION['admin'] = true;
        return true;
    }
    return false;
}

function require_admin(bool $api = false): void
{
    if (!is_installed()) {
        header('Location: ' . base_url('install.php'));
        exit;
    }
    if (is_admin()) return;
    if ($api) json_out(['error' => 'auth'], 401);
    header('Location: ' . base_url('admin/login.php'));
    exit;
}

function logout(): void
{
    start_session();
    $_SESSION = [];
    session_destroy();
    set_setting('auth_epoch', (string)((int)setting('auth_epoch', '1') + 1)); // invalide tous les cookies "rester connecté"
    setcookie('FIXITSUIVI_R', '', ['expires' => 1, 'path' => base_path()]);
}

function login_blocked(): bool
{
    $st = db()->prepare('SELECT COUNT(*) FROM login_fails WHERE ip = ? AND ts > ?');
    $st->execute([client_ip(), time() - 900]);
    return (int)$st->fetchColumn() >= 6;
}

function login_attempt(string $password): bool
{
    db()->prepare('DELETE FROM login_fails WHERE ts < ?')->execute([time() - 86400]);
    if (login_blocked()) return false;
    $hash = (string)setting('admin_hash', '');
    if ($hash !== '' && password_verify($password, $hash)) {
        start_session();
        session_regenerate_id(true);
        $_SESSION['admin'] = true;
        db()->prepare('DELETE FROM login_fails WHERE ip = ?')->execute([client_ip()]);
        set_remember_cookie();
        return true;
    }
    db()->prepare('INSERT INTO login_fails(ip, ts) VALUES(?, ?)')->execute([client_ip(), time()]);
    usleep(400000);
    return false;
}

function csrf_token(): string
{
    start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(20));
    return $_SESSION['csrf'];
}

function csrf_check(?string $t = null): bool
{
    $t ??= $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($t) && $t !== '' && hash_equals(csrf_token(), $t);
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function flash(?string $msg = null, string $type = 'ok'): ?array
{
    start_session();
    if ($msg !== null) {
        $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function redirect(string $path): never
{
    header('Location: ' . base_url($path));
    exit;
}

/* ───────────── Interventions ───────────── */

const STATUS_LABELS = [
    'planned' => 'Planifiée',
    'enroute' => 'En route',
    'arrived' => 'Arrivé sur place',
    'working' => 'Intervention en cours',
    'done' => 'Terminée',
    'cancelled' => 'Annulée',
];

const SERVICES = [
    'virus' => 'Suppression de virus / logiciels malveillants',
    'lent' => 'Ordinateur lent – optimisation',
    'wifi' => 'Wi-Fi / Internet / box',
    'donnees' => 'Récupération / transfert de données',
    'install' => 'Installation / configuration de logiciels',
    'nouveau' => 'Mise en service d\'un nouvel ordinateur',
    'windows' => 'Réinstallation / mise à jour Windows',
    'sauvegarde' => 'Sauvegarde & sécurité',
    'messagerie' => 'Messagerie / comptes en ligne',
    'imprimante' => 'Configuration imprimante / périphériques',
    'formation' => 'Formation / accompagnement',
    'autre' => 'Autre dépannage logiciel',
];

function get_iv(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM interventions WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function get_iv_by_token(string $token): ?array
{
    if (!preg_match('/^[A-Za-z0-9_-]{16,40}$/', $token)) return null;
    $st = db()->prepare('SELECT * FROM interventions WHERE token = ?');
    $st->execute([$token]);
    return $st->fetch() ?: null;
}

function update_iv(int $id, array $fields): void
{
    if (!$fields) return;
    $fields['updated_at'] = time();
    $sets = implode(', ', array_map(fn($k) => "$k = :$k", array_keys($fields)));
    $fields['id'] = $id;
    db()->prepare("UPDATE interventions SET $sets WHERE id = :id")->execute($fields);
}

function iv_services(array $iv): array
{
    $keys = json_decode((string)($iv['services'] ?? '[]'), true) ?: [];
    return array_values(array_filter(array_map(fn($k) => SERVICES[$k] ?? null, $keys)));
}

/* ───────────── Dates en français ───────────── */

function fr_date(int $ts, bool $withYear = false): string
{
    $days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    $months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    $s = $days[(int)date('w', $ts)] . ' ' . (int)date('j', $ts) . ($withYear ? '' : '') . ' ' . $months[(int)date('n', $ts) - 1];
    if ($withYear) $s .= ' ' . date('Y', $ts);
    return $s;
}

function fr_time(int $ts): string
{
    return date('G\hi', $ts);
}

function fr_relative_day(int $ts): string
{
    $d = date('Y-m-d', $ts);
    if ($d === date('Y-m-d')) return "aujourd'hui";
    if ($d === date('Y-m-d', strtotime('+1 day'))) return 'demain';
    return fr_date($ts);
}

function phone_display(?string $p): string
{
    $d = preg_replace('/\D+/', '', (string)$p);
    if (strlen($d) === 11 && str_starts_with($d, '33')) $d = '0' . substr($d, 2);
    if (strlen($d) === 10) return trim(chunk_split($d, 2, ' '));
    return (string)$p;
}

function phone_e164(?string $p): string
{
    $d = preg_replace('/\D+/', '', (string)$p);
    if (strlen($d) === 10 && $d[0] === '0') return '33' . substr($d, 1);
    return $d;
}

function app_key(): string
{
    $k = (string)setting('app_key', '');
    if ($k === '') {
        $k = random_token(24);
        set_setting('app_key', $k);
    }
    return $k;
}

function tech_name(): string { return (string)setting('tech_name', 'Jules'); }
function tech_phone(): string { return (string)setting('tech_phone', '06 15 51 73 81'); }
