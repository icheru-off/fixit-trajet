<?php
declare(strict_types=1);

function asset(string $p): string
{
    $file = APP_ROOT . '/assets/' . $p;
    $v = is_file($file) ? substr(md5((string)filemtime($file)), 0, 8) : APP_VERSION;
    return base_url('assets/' . $p) . '?v=' . $v;
}

function page_head(string $title, array $css = [], bool $map = false): void
{
    send_security_headers($map);
    no_cache();
    header('Content-Type: text/html; charset=utf-8');
    ?><!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<meta name="theme-color" content="#F6F4EF">
<meta name="format-detection" content="telephone=no">
<title><?= h($title) ?></title>
<link rel="icon" type="image/png" sizes="32x32" href="<?= h(asset('img/favicon-32.png')) ?>">
<link rel="apple-touch-icon" href="<?= h(asset('img/icon-180.png')) ?>">
<link rel="stylesheet" href="<?= h(asset('css/app.css')) ?>">
<?php if ($map): ?><link rel="stylesheet" href="<?= h(asset('vendor/maplibre-gl.css')) ?>"><?php endif; ?>
<?php foreach ($css as $c): ?><link rel="stylesheet" href="<?= h(asset($c)) ?>"><?php endforeach; ?>
</head>
<?php
}

function admin_header(string $title, string $active = ''): void
{
    page_head($title . ' · FixIT Suivi', [], in_array($active, ['drive'], true));
    $nav = [
        'list' => ['admin/', 'Interventions'],
        'new' => ['admin/edit.php', '+ Nouvelle'],
        'settings' => ['admin/settings.php', 'Réglages'],
    ];
    ?>
<body class="admin">
<header class="topbar"><div class="topbar-in">
  <a href="<?= h(base_url('admin/')) ?>"><img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT"></a>
  <span class="tag">// suivi d'intervention</span>
  <nav>
    <?php foreach ($nav as $k => [$href, $label]): ?>
      <a href="<?= h(base_url($href)) ?>" class="<?= $active === $k ? 'on' : '' ?>"><?= h($label) ?></a>
    <?php endforeach; ?>
  </nav>
</div></header>
<main class="wrap">
<?php
    if ($f = flash()) {
        echo '<div class="flash ' . h($f['type']) . '">' . h($f['msg']) . '</div>';
    }
}

function admin_footer(array $js = []): void
{
    ?>
</main>
<div class="toast" id="toast"></div>
<script src="<?= h(asset('js/admin.js')) ?>"></script>
<?php foreach ($js as $j): ?><script src="<?= h(asset($j)) ?>"></script><?php endforeach; ?>
</body>
</html>
<?php
}

function status_badge(string $st): string
{
    return '<span class="badge b-' . h($st) . '">' . h(STATUS_LABELS[$st] ?? $st) . '</span>';
}

function icon(string $name): string
{
    $p = [
        'copy' => '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>',
        'sms' => '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.4A8 8 0 1 1 21 12Z"/>',
        'wa' => '<path d="M20.5 11.6a8.5 8.5 0 0 1-12.6 7.5L3.5 20.5l1.4-4.3a8.5 8.5 0 1 1 15.6-4.6Z"/><path d="M9 9.5c.3 2.3 2.2 4.2 4.5 4.5l1.2-1.2 2 1-.4 1.6c-3.8.4-7.6-3.4-7.2-7.2L10.7 7.8l1 2Z"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'car' => '<path d="M5 17h14v-4l-2-5H7l-2 5v4Z"/><circle cx="8" cy="17" r="2"/><circle cx="16" cy="17" r="2"/>',
        'pin' => '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
        'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/>',
        'eye' => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'edit' => '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/>',
        'check' => '<path d="m5 12 5 5L20 7"/>',
        'flag' => '<path d="M5 21V4h11l-2 4 2 4H5"/>',
        'tool' => '<path d="M14.7 6.3a4 4 0 0 0 5 5L12 19a2.1 2.1 0 0 1-3-3l7.7-7.7Z"/><path d="m3 21 4-4"/>',
    ][$name] ?? '';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}
