<?php
/**
 * Messages prêts à envoyer manuellement au client (SMS, WhatsApp, e-mail).
 * {eta} est remplacé en direct dans la page admin quand l'heure d'arrivée est connue.
 */
declare(strict_types=1);

function client_greeting(array $iv): string
{
    $n = trim((string)$iv['client_name']);
    return $n !== '' ? $n : 'Madame, Monsieur';
}

function build_messages(array $iv): array
{
    $link = client_link((string)$iv['token']);
    $tech = tech_name();
    $tel = tech_phone();
    $who = client_greeting($iv);
    $when = fr_date((int)$iv['scheduled_at']) . ' vers ' . fr_time((int)$iv['scheduled_at']);
    $addr = trim((string)$iv['address']);

    return [
        'confirm' => [
            'title' => 'Confirmation du rendez-vous',
            'hint' => 'À envoyer dès que le rendez-vous est pris.',
            'subject' => 'FixIT – Confirmation de votre rendez-vous',
            'text' => "Bonjour $who,\n\nC'est $tech de FixIT. Votre rendez-vous est bien noté pour le $when, au $addr.\n\n"
                . "Le jour J, vous pourrez suivre mon arrivée en direct sur ce lien :\n$link\n\n"
                . "Un empêchement ? Appelez-moi au $tel.\n\nÀ bientôt !\n$tech – FixIT",
        ],
        'enroute' => [
            'title' => 'Je suis en route',
            'hint' => 'À envoyer au départ : l\'heure d\'arrivée se met à jour toute seule.',
            'subject' => 'FixIT – Votre technicien est en route',
            'text' => "Bonjour $who, je suis en route ! 🚗\n\n"
                . "Arrivée estimée vers {eta} (estimation selon la circulation).\n\n"
                . "Suivez mon trajet en direct ici :\n$link\n\n$tech – FixIT · $tel",
        ],
        'late' => [
            'title' => 'Petit retard',
            'hint' => 'Si la circulation vous retarde.',
            'subject' => 'FixIT – Petit retard',
            'text' => "Bonjour $who, la circulation me retarde un peu, désolé ! "
                . "Je serai chez vous vers {eta}.\n\nVous pouvez suivre mon arrivée en direct :\n$link\n\n$tech – FixIT · $tel",
        ],
        'thanks' => [
            'title' => 'Merci après l\'intervention',
            'hint' => 'Une fois l\'intervention terminée.',
            'subject' => 'FixIT – Merci pour votre confiance',
            'text' => "Merci $who pour votre confiance ! 🙏\n\n"
                . "Si vous avez la moindre question sur ce que nous avons fait, je reste joignable au $tel.\n\n"
                . "À bientôt,\n$tech – FixIT\nfixit-service.fr",
        ],
    ];
}
