<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$tab = $_GET['tab'] ?? 'today';
$dayStart = strtotime('today');
$dayEnd = strtotime('tomorrow');
$tabs = [
    'today' => "Aujourd'hui",
    'next' => 'À venir',
    'past' => 'Terminées',
    'all' => 'Toutes',
];
if (!isset($tabs[$tab])) $tab = 'today';

$active = db()->query("SELECT * FROM interventions WHERE status IN ('enroute','arrived','working') ORDER BY scheduled_at")->fetchAll();
$activeIds = array_column($active, 'id');

switch ($tab) {
    case 'today':
        $st = db()->prepare("SELECT * FROM interventions WHERE scheduled_at >= ? AND scheduled_at < ? ORDER BY scheduled_at");
        $st->execute([$dayStart, $dayEnd]);
        break;
    case 'next':
        $st = db()->prepare("SELECT * FROM interventions WHERE scheduled_at >= ? AND status NOT IN ('done','cancelled') ORDER BY scheduled_at LIMIT 200");
        $st->execute([$dayEnd]);
        break;
    case 'past':
        $st = db()->prepare("SELECT * FROM interventions WHERE status IN ('done','cancelled') ORDER BY scheduled_at DESC LIMIT 200");
        $st->execute();
        break;
    default:
        $st = db()->prepare("SELECT * FROM interventions ORDER BY scheduled_at DESC LIMIT 300");
        $st->execute();
}
$rows = array_values(array_filter($st->fetchAll(), fn($r) => !in_array($r['id'], $activeIds, true)));

admin_header('Interventions', 'list');

function iv_row(array $r): void
{
    $ts = (int)$r['scheduled_at'];
    ?>
    <a class="ivrow" href="<?= h(base_url('admin/view.php?id=' . $r['id'])) ?>">
      <div class="when"><b><?= h(fr_time($ts)) ?></b><span><?= h(date('d/m', $ts)) ?></span></div>
      <div style="min-width:0">
        <div class="who"><?= h($r['client_name']) ?></div>
        <div class="addr"><?= h($r['address']) ?></div>
      </div>
      <?= status_badge($r['status']) ?>
    </a>
    <?php
}
?>
<div class="pagehead">
  <div><div class="kicker">// tableau de bord</div><h1>Interventions</h1></div>
  <a class="btn btn-primary" href="<?= h(base_url('admin/edit.php')) ?>">+ Nouvelle intervention</a>
</div>

<?php if ($active): ?>
  <h3 style="margin-top:4px">En cours</h3>
  <div class="ivlist" style="margin-bottom:22px"><?php foreach ($active as $r) iv_row($r); ?></div>
<?php endif; ?>

<nav class="tabs">
  <?php foreach ($tabs as $k => $label): ?>
    <a class="<?= $tab === $k ? 'on' : '' ?>" href="?tab=<?= h($k) ?>"><?= h($label) ?></a>
  <?php endforeach; ?>
</nav>

<?php if (!$rows): ?>
  <div class="empty card">
    <img src="<?= h(asset('img/mascotte.webp')) ?>" alt="">
    <p><?= $tab === 'today' ? "Aucune intervention prévue aujourd'hui." : 'Rien à afficher ici.' ?></p>
    <a class="btn btn-primary" href="<?= h(base_url('admin/edit.php')) ?>">Planifier une intervention</a>
  </div>
<?php else: ?>
  <div class="ivlist"><?php foreach ($rows as $r) iv_row($r); ?></div>
<?php endif; ?>

<form method="post" action="<?= h(base_url('admin/logout.php')) ?>" style="margin-top:30px;text-align:center">
  <?= csrf_field() ?><button class="btn btn-ghost btn-sm muted" type="submit">Se déconnecter</button>
</form>
<?php admin_footer();
