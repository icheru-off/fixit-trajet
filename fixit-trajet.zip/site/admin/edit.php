<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$iv = $id ? get_iv($id) : null;
if ($id && !$iv) redirect('admin/');

$defaultTs = strtotime(date('Y-m-d H:00', time() + 3 * 3600));
$v = [
    'client_name' => $iv['client_name'] ?? '',
    'client_phone' => $iv['client_phone'] ?? '',
    'client_email' => $iv['client_email'] ?? '',
    'address' => $iv['address'] ?? '',
    'address_extra' => $iv['address_extra'] ?? '',
    'lat' => $iv['lat'] ?? '',
    'lon' => $iv['lon'] ?? '',
    'date' => date('Y-m-d', (int)($iv['scheduled_at'] ?? $defaultTs)),
    'time' => date('H:i', (int)($iv['scheduled_at'] ?? $defaultTs)),
    'duration_min' => (string)($iv['duration_min'] ?? 60),
    'services' => json_decode((string)($iv['services'] ?? '[]'), true) ?: [],
    'device' => $iv['device'] ?? '',
    'problem' => $iv['problem'] ?? '',
    'price_note' => $iv['price_note'] ?? 'Devis gratuit avant intervention',
    'notes' => $iv['notes'] ?? '',
];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $errors[] = 'Session expirée, réessayez.';
    }
    foreach ($v as $k => $_) {
        if ($k === 'services') {
            $v[$k] = array_values(array_intersect(array_keys(SERVICES), (array)($_POST['services'] ?? [])));
        } else {
            $v[$k] = trim((string)($_POST[$k] ?? ''));
        }
    }
    if ($v['client_name'] === '') $errors[] = 'Le nom du client est obligatoire.';
    if ($v['address'] === '') $errors[] = 'L\'adresse est obligatoire.';
    if ($v['client_email'] !== '' && !filter_var($v['client_email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail invalide.';
    $ts = strtotime($v['date'] . ' ' . $v['time']);
    if (!$ts) $errors[] = 'Date ou heure invalide.';

    // coordonnées : celles de l'autocomplétion, sinon géocodage côté serveur
    $lat = $v['lat'];
    $lon = $v['lon'];
    $addrChanged = !$iv || $iv['address'] !== $v['address'];
    if ((!is_numeric($lat) || !is_numeric($lon)) || ($addrChanged && ($_POST['ac_ok'] ?? '') !== '1')) {
        $g = $v['address'] !== '' ? geocode_search($v['address'], 1) : [];
        if ($g) {
            $lat = $g[0]['lat'];
            $lon = $g[0]['lon'];
        } elseif (!is_numeric($lat) || !is_numeric($lon)) {
            $errors[] = 'Adresse introuvable : choisissez-la dans la liste de suggestions.';
        }
    }

    if (!$errors) {
        $data = [
            'client_name' => mb_substr($v['client_name'], 0, 120),
            'client_phone' => mb_substr($v['client_phone'], 0, 30),
            'client_email' => mb_substr($v['client_email'], 0, 160),
            'address' => mb_substr($v['address'], 0, 250),
            'address_extra' => mb_substr($v['address_extra'], 0, 250),
            'lat' => (float)$lat,
            'lon' => (float)$lon,
            'scheduled_at' => $ts,
            'duration_min' => max(15, min(600, (int)$v['duration_min'])),
            'services' => json_encode($v['services']),
            'device' => mb_substr($v['device'], 0, 160),
            'problem' => mb_substr($v['problem'], 0, 2000),
            'price_note' => mb_substr($v['price_note'], 0, 200),
            'notes' => mb_substr($v['notes'], 0, 4000),
        ];
        if ($iv) {
            update_iv((int)$iv['id'], $data);
            flash('Intervention mise à jour.');
            redirect('admin/view.php?id=' . $iv['id']);
        }
        $data += ['token' => random_token(16), 'status' => 'planned', 'created_at' => time(), 'updated_at' => time()];
        $cols = implode(',', array_keys($data));
        $ph = implode(',', array_fill(0, count($data), '?'));
        db()->prepare("INSERT INTO interventions($cols) VALUES($ph)")->execute(array_values($data));
        $newId = (int)db()->lastInsertId();
        flash('Intervention créée : le lien de suivi et les messages sont prêts.');
        redirect('admin/view.php?id=' . $newId);
    }
}

admin_header($iv ? 'Modifier' : 'Nouvelle intervention', $iv ? '' : 'new');
?>
<div class="wrap-narrow" style="margin:0 auto">
<div class="pagehead">
  <div><div class="kicker">// <?= $iv ? 'modifier' : 'nouvelle intervention' ?></div><h1><?= $iv ? h($iv['client_name']) : 'Planifier une intervention' ?></h1></div>
</div>
<?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>

<form method="post" autocomplete="off">
  <?= csrf_field() ?>
  <section class="card">
    <h2>Client</h2>
    <label class="field"><span>Nom du client *</span><input type="text" name="client_name" value="<?= h($v['client_name']) ?>" required placeholder="Ex. : Mme Martin">
      <small>Utilisé tel quel dans les messages : « Bonjour Mme Martin ».</small></label>
    <div class="grid2">
      <label class="field"><span>Téléphone</span><input type="tel" name="client_phone" value="<?= h($v['client_phone']) ?>" placeholder="06 12 34 56 78"></label>
      <label class="field"><span>E-mail</span><input type="email" name="client_email" value="<?= h($v['client_email']) ?>" placeholder="client@exemple.fr"></label>
    </div>
  </section>

  <section class="card">
    <h2>Lieu & horaire</h2>
    <div class="field ac" data-ac data-proxy="<?= h(base_url('api/geocode.php')) ?>">
      <span style="display:block;font-weight:600;font-size:14px;margin-bottom:6px">Adresse de l'intervention *</span>
      <input type="text" name="address" value="<?= h($v['address']) ?>" required placeholder="Tapez l'adresse puis choisissez-la" data-ac-input>
      <input type="hidden" name="lat" value="<?= h($v['lat']) ?>" data-ac-lat>
      <input type="hidden" name="lon" value="<?= h($v['lon']) ?>" data-ac-lon>
      <input type="hidden" name="ac_ok" value="<?= $iv ? '1' : '0' ?>" data-ac-ok>
    </div>
    <label class="field"><span>Complément d'adresse</span><input type="text" name="address_extra" value="<?= h($v['address_extra']) ?>" placeholder="Bâtiment, étage, digicode, portail…"></label>
    <div class="grid3">
      <label class="field"><span>Date *</span><input type="date" name="date" value="<?= h($v['date']) ?>" required></label>
      <label class="field"><span>Heure d'arrivée prévue *</span><input type="time" name="time" value="<?= h($v['time']) ?>" required step="300"></label>
      <label class="field"><span>Durée estimée</span>
        <select name="duration_min">
          <?php foreach ([30 => '30 min', 45 => '45 min', 60 => '1 h', 90 => '1 h 30', 120 => '2 h', 150 => '2 h 30', 180 => '3 h', 240 => '4 h'] as $m => $l): ?>
            <option value="<?= $m ?>" <?= (int)$v['duration_min'] === $m ? 'selected' : '' ?>><?= $l ?></option>
          <?php endforeach; ?>
        </select></label>
    </div>
  </section>

  <section class="card">
    <h2>Intervention</h2>
    <div class="field"><span style="display:block;font-weight:600;font-size:14px;margin-bottom:8px">Prestations</span>
      <div class="chips">
        <?php foreach (SERVICES as $k => $label): ?>
          <label class="chip"><input type="checkbox" name="services[]" value="<?= h($k) ?>" <?= in_array($k, $v['services'], true) ? 'checked' : '' ?>><span><?= h($label) ?></span></label>
        <?php endforeach; ?>
      </div>
    </div>
    <label class="field"><span>Matériel concerné</span><input type="text" name="device" value="<?= h($v['device']) ?>" placeholder="Ex. : PC portable HP sous Windows 11"></label>
    <label class="field"><span>Problème signalé</span><textarea name="problem" placeholder="Ce que le client vous a décrit (visible par le client sur sa page de suivi)"><?= h($v['problem']) ?></textarea></label>
    <label class="field"><span>Tarif / devis (visible par le client)</span><input type="text" name="price_note" value="<?= h($v['price_note']) ?>" placeholder="Ex. : Devis gratuit avant intervention"></label>
    <label class="field"><span>Notes privées</span><textarea name="notes" placeholder="Visible uniquement par vous (mots de passe à ne pas noter ici)"><?= h($v['notes']) ?></textarea></label>
  </section>

  <div class="actions" style="margin-top:18px">
    <button class="btn btn-primary btn-lg" type="submit"><?= $iv ? 'Enregistrer' : 'Créer et générer le lien' ?></button>
    <a class="btn btn-lg" href="<?= h(base_url($iv ? 'admin/view.php?id=' . $iv['id'] : 'admin/')) ?>">Annuler</a>
  </div>
</form>
</div>
<?php admin_footer();
