<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (!is_installed()) redirect('install.php');
if (is_admin()) redirect('admin/');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $error = 'Session expirée, réessayez.';
    } elseif (login_blocked()) {
        $error = 'Trop de tentatives. Réessayez dans 15 minutes.';
    } elseif (login_attempt((string)($_POST['password'] ?? ''))) {
        redirect('admin/');
    } else {
        $error = 'Mot de passe incorrect.';
    }
}
page_head('Connexion · FixIT Suivi');
?>
<body>
<div class="login"><form class="card" method="post">
  <img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT">
  <div class="kicker">// espace technicien</div>
  <h1 style="margin-bottom:18px">Connexion</h1>
  <?php if ($error): ?><div class="flash err"><?= h($error) ?></div><?php endif; ?>
  <?= csrf_field() ?>
  <label class="field"><span>Mot de passe</span><input type="password" name="password" required autofocus autocomplete="current-password"></label>
  <button class="btn btn-primary btn-block btn-lg" type="submit">Se connecter</button>
  <p class="muted small" style="margin:14px 0 0">Vous restez connecté 60 jours sur cet appareil.</p>
</form></div>
</body>
</html>
