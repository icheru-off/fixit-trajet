<?php
/** Mode trajet : à ouvrir sur l'iPhone au moment de partir. Partage la position GPS en direct. */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$iv = get_iv((int)($_GET['id'] ?? 0));
if (!$iv) redirect('admin/');
$msgs = build_messages($iv);
$boot = [
    'id' => (int)$iv['id'],
    'status' => $iv['status'],
    'csrf' => csrf_token(),
    'trackUrl' => base_url('api/track.php'),
    'actionUrl' => base_url('admin/action.php'),
    'viewUrl' => base_url('admin/view.php?id=' . $iv['id']),
    'dest' => ['lat' => (float)$iv['lat'], 'lon' => (float)$iv['lon']],
    'styleUrl' => map_style_url(),
    'workerUrl' => asset('vendor/maplibre-gl-csp-worker.js'),
    'phone' => phone_e164($iv['client_phone']),
    'enrouteMsg' => $msgs['enroute']['text'],
];
page_head('Mode trajet · ' . $iv['client_name'], ['css/drive.css'], true);
?>
<body class="drive">
<script type="application/json" id="boot"><?= json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>

<header class="d-top">
  <a class="d-back" href="<?= h($boot['viewUrl']) ?>" aria-label="Retour">‹</a>
  <div class="d-who"><b><?= h($iv['client_name']) ?></b><span><?= h($iv['address']) ?></span></div>
  <span class="d-gps" id="gps"><i></i><em>GPS</em></span>
</header>

<div id="map" class="d-map"></div>

<section class="d-panel">
  <div class="d-banner hidden" id="banner"></div>

  <div class="d-eta" id="etaBox">
    <div><span class="d-lbl">Arrivée estimée</span><b id="etaClock">–</b></div>
    <div><span class="d-lbl">Restant</span><b id="etaRem">–</b></div>
    <div><span class="d-lbl">Distance</span><b id="etaDist">–</b></div>
  </div>
  <p class="d-info" id="info">Appuyez sur « Je pars » au moment de prendre la route.</p>

  <div id="ctlPlanned" class="d-ctl">
    <button class="btn btn-primary btn-lg btn-block" id="btnStart" type="button">🚗 Je pars</button>
  </div>
  <div id="ctlEnroute" class="d-ctl hidden">
    <div class="d-grid">
      <button class="btn btn-ok btn-lg" id="btnArrived" type="button">Je suis arrivé</button>
      <button class="btn btn-lg" id="btnMsg" type="button">SMS au client</button>
    </div>
    <div class="d-grid d-links">
      <a class="btn btn-sm" target="_blank" rel="noopener" href="https://waze.com/ul?ll=<?= h(rawurlencode($iv['lat'] . ',' . $iv['lon'])) ?>&amp;navigate=yes">Ouvrir Waze</a>
      <a class="btn btn-sm" target="_blank" rel="noopener" href="https://maps.apple.com/?daddr=<?= h(rawurlencode($iv['lat'] . ',' . $iv['lon'])) ?>&amp;dirflg=d">Plans</a>
      <button class="btn btn-sm btn-danger" id="btnStop" type="button">Arrêter</button>
    </div>
  </div>
  <div id="ctlArrived" class="d-ctl hidden">
    <p class="d-done">Vous êtes arrivé ✅ Le partage de position est coupé.</p>
    <a class="btn btn-lg btn-block" href="<?= h($boot['viewUrl']) ?>">Retour à la fiche</a>
  </div>
  <p class="d-tip">Gardez cette page ouverte et l'écran allumé pendant le trajet (support voiture). Pour un suivi écran verrouillé, utilisez OwnTracks (voir Réglages).</p>
</section>

<div class="toast" id="toast"></div>
<script src="<?= h(asset('vendor/maplibre-gl-csp.js')) ?>"></script>
<script src="<?= h(asset('js/map.js')) ?>"></script>
<script src="<?= h(asset('js/admin.js')) ?>"></script>
<script src="<?= h(asset('js/drive.js')) ?>"></script>
</body>
</html>
