<?php
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin();

$test = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        flash('Session expirée, réessayez.', 'err');
        redirect('admin/settings.php');
    }
    $sec = (string)($_POST['section'] ?? '');
    switch ($sec) {
        case 'profile':
            set_setting('tech_name', trim((string)$_POST['tech_name']) ?: 'Jules');
            set_setting('tech_phone', trim((string)$_POST['tech_phone']));
            $home = trim((string)($_POST['home'] ?? ''));
            set_setting('home_address', $home);
            $lat = $_POST['home_lat'] ?? '';
            $lon = $_POST['home_lon'] ?? '';
            if ($home !== '' && (!is_numeric($lat) || !is_numeric($lon))) {
                $g = geocode_search($home, 1);
                if ($g) { $lat = $g[0]['lat']; $lon = $g[0]['lon']; }
            }
            set_setting('home_lat', $home !== '' && is_numeric($lat) ? (string)$lat : '');
            set_setting('home_lon', $home !== '' && is_numeric($lon) ? (string)$lon : '');
            set_setting('privacy_m', (string)max(0, min(5000, (int)$_POST['privacy_m'])));
            set_setting('parking_min', (string)max(0, min(15, (int)$_POST['parking_min'])));
            flash('Profil enregistré.');
            break;
        case 'eta':
            set_setting('tomtom_key', trim((string)$_POST['tomtom_key']));
            $style = (string)($_POST['map_style'] ?? 'positron');
            set_setting('map_style', in_array($style, ['positron', 'liberty', 'bright'], true) ? $style : 'positron');
            if (!empty($_POST['reset_learning'])) {
                set_setting('learn_osrm', '1.10'); set_setting('learn_osrm_n', '0');
                set_setting('learn_tt', '1.0'); set_setting('learn_tt_n', '0');
            }
            flash('Réglages du calcul enregistrés.');
            break;
        case 'keys':
            if (!empty($_POST['regen_app'])) set_setting('app_key', random_token(24));
            if (!empty($_POST['regen_ot'])) set_setting('owntracks_key', random_token(18));
            flash('Nouvelle clé générée : reconfigurez l\'application concernée.');
            break;
        case 'password':
            $cur = (string)($_POST['current'] ?? '');
            $new = (string)($_POST['new'] ?? '');
            if (!password_verify($cur, (string)setting('admin_hash'))) flash('Mot de passe actuel incorrect.', 'err');
            elseif (mb_strlen($new) < 10) flash('Le nouveau mot de passe doit faire au moins 10 caractères.', 'err');
            else {
                set_setting('admin_hash', password_hash($new, PASSWORD_DEFAULT));
                set_setting('auth_epoch', (string)((int)setting('auth_epoch', '1') + 1));
                set_remember_cookie();
                flash('Mot de passe modifié. Les autres appareils sont déconnectés.');
            }
            break;
        case 'test':
            $t0 = microtime(true);
            $g = geocode_search('Mairie, 77130 La Grande-Paroisse', 1);
            $t1 = microtime(true);
            $r = route_osrm(OSRM_PRIMARY, 48.3870, 2.9040, 48.5390, 2.6600);
            $t2 = microtime(true);
            $r2 = route_osrm(OSRM_FALLBACK, 48.3870, 2.9040, 48.5390, 2.6600);
            $t3 = microtime(true);
            $tt = null;
            if (trim((string)setting('tomtom_key', '')) !== '') $tt = route_tomtom(trim((string)setting('tomtom_key')), 48.3870, 2.9040, 48.5390, 2.6600);
            $test = [
                ['Adresses (IGN Géoplateforme)', (bool)$g, $g ? $g[0]['label'] : 'injoignable', $t1 - $t0],
                ['Itinéraire OSRM (principal)', (bool)$r, $r ? round($r['dist_m'] / 1000, 1) . ' km · ' . round($r['raw_s'] / 60) . ' min sans trafic' : 'injoignable', $t2 - $t1],
                ['Itinéraire OSRM FOSSGIS (secours)', (bool)$r2, $r2 ? round($r2['dist_m'] / 1000, 1) . ' km · ' . round($r2['raw_s'] / 60) . ' min sans trafic' : 'injoignable', $t3 - $t2],
            ];
            if ($tt !== null || trim((string)setting('tomtom_key', '')) !== '') {
                $test[] = ['TomTom trafic temps réel', (bool)$tt, $tt ? round($tt['raw_s'] / 60) . ' min avec trafic (dont ' . round($tt['delay_s'] / 60) . ' min de retard)' : 'clé refusée ou quota atteint', 0];
            }
            break;
    }
    if ($sec !== 'test') redirect('admin/settings.php');
}

$appKey = app_key();
$otKey = (string)setting('owntracks_key', '');
if ($otKey === '') { $otKey = random_token(18); set_setting('owntracks_key', $otKey); }
$setupLink = 'fixittrajet://setup?server=' . rawurlencode(rtrim(base_url(), '/')) . '&key=' . rawurlencode($appKey);
$otUrl = base_url('api/owntracks.php') . '?key=' . $otKey;
$appSeen = (int)setting('app_last_seen', 0);
$otSeen = (int)setting('owntracks_last', 0);
$ttCount = setting('tt_month') === date('Y-m') ? (int)setting('tt_count', 0) : 0;

admin_header('Réglages', 'settings');
?>
<div class="wrap-narrow" style="margin:0 auto">
<div class="pagehead"><div><div class="kicker">// réglages</div><h1>Réglages</h1></div></div>

<form class="card" method="post" autocomplete="off">
  <?= csrf_field() ?><input type="hidden" name="section" value="profile">
  <h2>Profil & confidentialité</h2>
  <div class="grid2">
    <label class="field"><span>Prénom affiché aux clients</span><input type="text" name="tech_name" value="<?= h(tech_name()) ?>"></label>
    <label class="field"><span>Téléphone pro</span><input type="tel" name="tech_phone" value="<?= h(tech_phone()) ?>"></label>
  </div>
  <div class="field ac" data-ac data-proxy="<?= h(base_url('api/geocode.php')) ?>">
    <span style="display:block;font-weight:600;font-size:14px;margin-bottom:6px">Adresse du domicile (point de départ habituel)</span>
    <input type="text" name="home" value="<?= h(setting('home_address', '')) ?>" data-ac-input placeholder="Votre adresse">
    <input type="hidden" name="home_lat" value="<?= h(setting('home_lat', '')) ?>" data-ac-lat>
    <input type="hidden" name="home_lon" value="<?= h(setting('home_lon', '')) ?>" data-ac-lon>
  </div>
  <div class="grid2">
    <label class="field"><span>Zone masquée autour du domicile</span>
      <select name="privacy_m">
        <?php foreach ([0 => 'Désactivée', 500 => '500 m', 800 => '800 m', 1500 => '1,5 km', 3000 => '3 km'] as $m => $l): ?>
          <option value="<?= $m ?>" <?= (int)setting('privacy_m', 800) === $m ? 'selected' : '' ?>><?= $l ?></option>
        <?php endforeach; ?>
      </select>
      <small>Dans cette zone, le client voit l'heure d'arrivée mais pas votre position : votre adresse reste privée.</small></label>
    <label class="field"><span>Temps pour se garer</span>
      <select name="parking_min">
        <?php foreach ([0, 1, 2, 3, 5] as $m): ?><option value="<?= $m ?>" <?= (int)setting('parking_min', 2) === $m ? 'selected' : '' ?>><?= $m ?> min</option><?php endforeach; ?>
      </select><small>Ajouté à l'heure d'arrivée annoncée.</small></label>
  </div>
  <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="eta">
  <h2>Calcul de l'heure d'arrivée</h2>
  <p class="muted small">Par défaut : itinéraire OSRM (OpenStreetMap, limitations de vitesse) + modèle des heures de pointe en Île-de-France
    + correction en direct selon votre vitesse GPS réelle (bouchons, accidents, ralentissements) + apprentissage de vos trajets. 100 % gratuit, sans clé.</p>
  <dl class="kv" style="margin-bottom:14px">
    <dt>Coefficient appris</dt><dd>×<?= h(number_format(learned_factor(false), 2, ',', '')) ?> <span class="muted small">(<?= (int)setting('learn_osrm_n', 0) ?> trajet(s) mesuré(s))</span></dd>
  </dl>
  <label class="field"><span>Clé TomTom (facultatif – trafic temps réel)</span>
    <input type="text" name="tomtom_key" value="<?= h(setting('tomtom_key', '')) ?>" placeholder="Laisser vide pour rester 100 % OpenStreetMap">
    <small>Compte gratuit sur developer.tomtom.com, sans carte bancaire : 20 000 calculs / mois offerts, soit largement assez pour un technicien.
      Ajoute les bouchons et accidents en temps réel. Utilisation ce mois-ci : <?= $ttCount ?> / <?= TOMTOM_MONTHLY_CAP ?> (au-delà, retour automatique à OSRM).</small></label>
  <label class="field"><span>Style de carte (client)</span>
    <select name="map_style">
      <?php foreach (['positron' => 'Positron – clair et épuré', 'liberty' => 'Liberty – coloré', 'bright' => 'Bright – contrasté'] as $k => $l): ?>
        <option value="<?= $k ?>" <?= setting('map_style', 'positron') === $k ? 'selected' : '' ?>><?= $l ?></option>
      <?php endforeach; ?>
    </select></label>
  <label class="chip" style="display:inline-block;margin-bottom:14px"><input type="checkbox" name="reset_learning" value="1"><span>Réinitialiser l'apprentissage</span></label><br>
  <button class="btn btn-primary" type="submit">Enregistrer</button>
</form>

<section class="card" id="app">
  <div class="kicker">// recommandé</div>
  <h2>Application iPhone « FixIT Trajet »</h2>
  <p class="muted small">Suivi GPS natif : fonctionne écran verrouillé, mesure la vitesse réelle et garde les positions en mémoire dans les zones sans réseau.
    Une fois l'app installée (voir le guide dans le zip), ouvrez cette page <b>sur l'iPhone</b> et touchez le bouton :</p>
  <a class="btn btn-primary btn-block" href="<?= h($setupLink) ?>">Configurer l'app automatiquement</a>
  <p class="small muted" style="margin:12px 0 6px">Ou saisie manuelle dans l'app :</p>
  <label class="field"><span>Adresse du serveur</span><div class="linkbox"><input type="text" readonly id="srv" value="<?= h(rtrim(base_url(), '/')) ?>"><button class="btn" type="button" data-copy="#srv"><?= icon('copy') ?></button></div></label>
  <label class="field"><span>Clé de l'application</span><div class="linkbox"><input type="text" readonly id="akey" value="<?= h($appKey) ?>"><button class="btn" type="button" data-copy="#akey"><?= icon('copy') ?></button></div></label>
  <p class="small muted">Dernière connexion de l'app : <?= $appSeen ? h(fr_relative_day($appSeen) . ' à ' . fr_time($appSeen)) : 'jamais' ?></p>
</section>

<section class="card">
  <h2>Alternative : OwnTracks (App Store, gratuit)</h2>
  <p class="muted small">Si vous ne voulez pas installer l'IPA : installez « OwnTracks » depuis l'App Store, puis dans Réglages › Connexion :
    Mode <b>HTTP</b>, URL ci-dessous, et passez l'app en mode <b>Déplacement (Move)</b> pendant vos trajets. Démarrez le trajet depuis la fiche intervention.</p>
  <div class="linkbox"><input type="text" readonly id="oturl" value="<?= h($otUrl) ?>"><button class="btn" type="button" data-copy="#oturl"><?= icon('copy') ?></button></div>
  <p class="small muted">Dernière position reçue : <?= $otSeen ? h(fr_relative_day($otSeen) . ' à ' . fr_time($otSeen)) : 'jamais' ?></p>
</section>

<form class="card" method="post" data-confirm="Générer une nouvelle clé ? L'ancienne ne fonctionnera plus.">
  <?= csrf_field() ?><input type="hidden" name="section" value="keys">
  <h3>Clés de sécurité</h3>
  <div class="actions">
    <button class="btn btn-sm" name="regen_app" value="1" type="submit">Nouvelle clé app iPhone</button>
    <button class="btn btn-sm" name="regen_ot" value="1" type="submit">Nouvelle clé OwnTracks</button>
  </div>
</form>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="test">
  <h2>Tester les services gratuits</h2>
  <p class="muted small">Vérifie que votre hébergement o2switch joint bien les services d'adresses et d'itinéraire.</p>
  <?php if ($test): ?>
    <ul style="padding-left:0;list-style:none">
      <?php foreach ($test as [$label, $ok, $detail, $dt]): ?>
        <li style="margin-bottom:6px"><?= $ok ? '✅' : '❌' ?> <b><?= h($label) ?></b> — <?= h($detail) ?><?= $dt ? ' <span class="muted small">(' . number_format($dt, 2, ',', '') . ' s)</span>' : '' ?></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <button class="btn" type="submit">Lancer le test</button>
</form>

<form class="card" method="post">
  <?= csrf_field() ?><input type="hidden" name="section" value="password">
  <h2>Mot de passe</h2>
  <div class="grid2">
    <label class="field"><span>Actuel</span><input type="password" name="current" required autocomplete="current-password"></label>
    <label class="field"><span>Nouveau (10 car. min.)</span><input type="password" name="new" minlength="10" required autocomplete="new-password"></label>
  </div>
  <button class="btn" type="submit">Changer le mot de passe</button>
</form>
</div>
<?php admin_footer();
