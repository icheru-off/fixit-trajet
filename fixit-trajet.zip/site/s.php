<?php
/** Page de suivi client : https://…/s/{jeton} */
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$token = (string)($_GET['k'] ?? '');
$iv = is_installed() ? get_iv_by_token($token) : null;

if (!$iv || $iv['status'] === 'cancelled') {
    http_response_code(404);
    page_head('Suivi FixIT');
    ?>
<body class="client">
<div class="login"><div class="card" style="text-align:center;max-width:420px">
  <img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT">
  <h2><?= $iv ? 'Intervention annulée' : 'Lien introuvable' ?></h2>
  <p class="muted"><?= $iv ? 'Ce rendez-vous a été annulé.' : 'Ce lien de suivi n\'existe pas ou n\'est plus valable.' ?> Une question ? Appelez FixIT au <a href="tel:+<?= h(phone_e164(tech_phone())) ?>"><?= h(tech_phone()) ?></a>.</p>
</div></div>
</body></html>
<?php
    exit;
}

$state = public_state($iv);
$ts = (int)$iv['scheduled_at'];
$boot = [
    'token' => $iv['token'],
    'statusUrl' => base_url('api/status.php'),
    'styleUrl' => map_style_url(),
    'workerUrl' => asset('vendor/maplibre-gl-csp-worker.js'),
    'state' => $state,
    'tech' => tech_name(),
];
page_head('Suivi de votre intervention · FixIT', ['css/client.css'], true);
?>
<body class="client">
<script type="application/json" id="boot"><?= json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>

<header class="c-top">
  <img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT">
  <span class="live" id="liveTag"><i></i>Suivi en direct</span>
</header>

<main class="c-wrap">
  <section class="c-hero" id="hero" data-status="<?= h($iv['status']) ?>">
    <div class="c-kicker" id="heroKicker">Votre intervention</div>
    <div class="c-title" id="heroTitle">Chargement…</div>
    <div class="c-big" id="heroBig"></div>
    <div class="c-sub" id="heroSub"></div>
    <div class="c-note" id="heroNote"></div>
    <img class="c-mascot" src="<?= h(asset('img/mascotte.webp')) ?>" alt="">
  </section>

  <section class="c-mapcard" id="mapCard">
    <div id="map" class="c-map" aria-label="Carte du trajet du technicien"></div>
    <button class="c-recenter hidden" id="recenter" type="button">Recentrer</button>
    <div class="c-mapmsg hidden" id="mapMsg"></div>
  </section>

  <ol class="c-steps" id="steps">
    <li data-s="planned"><i></i><span>Rendez-vous<br>confirmé</span></li>
    <li data-s="enroute"><i></i><span>Technicien<br>en route</span></li>
    <li data-s="arrived"><i></i><span>Arrivé<br>chez vous</span></li>
    <li data-s="working"><i></i><span>Intervention<br>en cours</span></li>
    <li data-s="done"><i></i><span>Terminée</span></li>
  </ol>

  <section class="c-card">
    <div class="c-row"><span>Rendez-vous</span><b><?= h(ucfirst(fr_date($ts))) ?> · <?= h(fr_time($ts)) ?></b></div>
    <div class="c-row"><span>Adresse</span><b><?= h($iv['address']) ?></b></div>
    <?php if ($s = iv_services($iv)): ?><div class="c-row"><span>Prestation</span><b><?= h(implode(', ', $s)) ?></b></div><?php endif; ?>
    <?php if ($iv['price_note']): ?><div class="c-row"><span>Tarif</span><b><?= h($iv['price_note']) ?></b></div><?php endif; ?>
    <div class="c-row"><span>Votre technicien</span><b><?= h(tech_name()) ?> · FixIT</b></div>
    <div class="c-actions">
      <a class="btn btn-primary" href="tel:+<?= h(phone_e164(tech_phone())) ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"/></svg>
        Appeler <?= h(tech_name()) ?></a>
      <a class="btn" href="sms:+<?= h(phone_e164(tech_phone())) ?>">Envoyer un SMS</a>
    </div>
  </section>

  <footer class="c-foot">
    <p>Ce lien est personnel : il n'affiche la position du technicien que pendant son trajet vers chez vous.</p>
    <p><a href="https://fixit-service.fr" rel="noopener">fixit-service.fr</a> · Dépannage informatique à domicile · Seine-et-Marne</p>
  </footer>
</main>

<script src="<?= h(asset('vendor/maplibre-gl-csp.js')) ?>"></script>
<script src="<?= h(asset('js/map.js')) ?>"></script>
<script src="<?= h(asset('js/client.js')) ?>"></script>
</body>
</html>
