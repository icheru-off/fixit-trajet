<?php
/**
 * Installation de FixIT Suivi (à lancer une seule fois).
 * Crée la base SQLite, le mot de passe administrateur et les réglages de base.
 */
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';

$errors = [];
$checks = [
    'PHP 8.1 ou plus' => version_compare(PHP_VERSION, '8.1.0', '>='),
    'Extension SQLite (pdo_sqlite)' => extension_loaded('pdo_sqlite'),
    'Appels web sortants (curl)' => function_exists('curl_init') || (bool)ini_get('allow_url_fopen'),
    'Dossier data/ inscriptible' => is_writable(DATA_DIR),
    'Connexion HTTPS' => is_https(),
];

if (is_installed()) {
    page_head('FixIT Suivi – déjà installé');
    echo '<body><div class="login"><div class="card"><img class="logo" src="' . h(asset('img/logo-light.png')) . '" alt="FixIT">'
        . '<h2>Déjà installé ✅</h2><p class="muted">Pour des raisons de sécurité, supprimez le fichier <b>install.php</b> s\'il est encore présent.</p>'
        . '<a class="btn btn-primary btn-block" href="' . h(base_url('admin/login.php')) . '">Aller à l\'espace admin</a></div></div></body></html>';
    exit;
}

$v = ['tech_name' => 'Jules', 'tech_phone' => '06 15 51 73 81', 'home' => '', 'home_lat' => '', 'home_lon' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) $v[$k] = trim((string)($_POST[$k] ?? ''));
    $pw = (string)($_POST['password'] ?? '');
    $pw2 = (string)($_POST['password2'] ?? '');
    if (in_array(false, array_slice($checks, 0, 4, true), true)) $errors[] = 'Le serveur ne remplit pas les conditions ci-dessous.';
    if (mb_strlen($pw) < 10) $errors[] = 'Le mot de passe doit faire au moins 10 caractères.';
    if ($pw !== $pw2) $errors[] = 'Les deux mots de passe ne correspondent pas.';
    if ($v['tech_name'] === '') $errors[] = 'Indiquez votre prénom.';

    if (!$errors) {
        $config = [
            'secret' => bin2hex(random_bytes(32)),
            'db_file' => 'suivi-' . bin2hex(random_bytes(8)) . '.sqlite',
            'base_url' => detect_base_url(),
            'installed_at' => date('c'),
        ];
        $php = "<?php\n// Généré par install.php — ne pas partager.\nreturn " . var_export($config, true) . ";\n";
        if (@file_put_contents(CONFIG_FILE, $php, LOCK_EX) === false) {
            $errors[] = 'Impossible d\'écrire data/config.php (droits du dossier data/).';
        } else {
            @chmod(CONFIG_FILE, 0600);
            cfg_reset();
            set_setting('admin_hash', password_hash($pw, PASSWORD_DEFAULT));
            set_setting('tech_name', $v['tech_name']);
            set_setting('tech_phone', $v['tech_phone']);
            set_setting('privacy_m', '800');
            set_setting('parking_min', '2');
            set_setting('map_style', 'positron');
            set_setting('owntracks_key', random_token(18));
            set_setting('auth_epoch', '1');
            if ($v['home'] !== '') {
                $lat = $v['home_lat'];
                $lon = $v['home_lon'];
                if (!is_numeric($lat) || !is_numeric($lon)) {
                    $g = geocode_search($v['home'], 1);
                    if ($g) { $lat = $g[0]['lat']; $lon = $g[0]['lon']; }
                }
                set_setting('home_address', $v['home']);
                if (is_numeric($lat) && is_numeric($lon)) {
                    set_setting('home_lat', (string)$lat);
                    set_setting('home_lon', (string)$lon);
                }
            }
            @unlink(__FILE__); // supprime l'installateur
            start_session();
            $_SESSION['admin'] = true;
            set_remember_cookie();
            flash('Installation terminée. Bienvenue ' . $v['tech_name'] . ' !');
            header('Location: ' . base_url('admin/'));
            exit;
        }
    }
}

page_head('Installation · FixIT Suivi');
?>
<body>
<div class="login"><div class="card" style="max-width:520px">
  <img class="logo" src="<?= h(asset('img/logo-light.png')) ?>" alt="FixIT">
  <div class="kicker">// installation</div>
  <h1>FixIT Suivi</h1>
  <p class="muted">Créez votre accès administrateur. Seul ce mot de passe permet d'entrer dans l'espace de gestion.</p>

  <ul style="list-style:none;padding:0;margin:0 0 18px;font-size:14px">
    <?php foreach ($checks as $label => $ok): ?>
      <li><?= $ok ? '✅' : ($label === 'Connexion HTTPS' ? '⚠️' : '❌') ?> <?= h($label) ?>
        <?php if (!$ok && $label === 'Connexion HTTPS'): ?><span class="muted">– activez le certificat SSL (le GPS de l'iPhone exige HTTPS)</span><?php endif; ?></li>
    <?php endforeach; ?>
  </ul>

  <?php foreach ($errors as $e): ?><div class="flash err"><?= h($e) ?></div><?php endforeach; ?>

  <form method="post" autocomplete="off">
    <div class="grid2">
      <label class="field"><span>Votre prénom</span><input type="text" name="tech_name" value="<?= h($v['tech_name']) ?>" required></label>
      <label class="field"><span>Téléphone pro</span><input type="tel" name="tech_phone" value="<?= h($v['tech_phone']) ?>"></label>
    </div>
    <label class="field"><span>Mot de passe administrateur</span><input type="password" name="password" minlength="10" required autocomplete="new-password"><small>10 caractères minimum.</small></label>
    <label class="field"><span>Confirmer le mot de passe</span><input type="password" name="password2" minlength="10" required autocomplete="new-password"></label>
    <div class="field ac" data-ac>
      <span style="display:block;font-weight:600;font-size:14px;margin-bottom:6px">Votre adresse de départ habituelle (domicile)</span>
      <input type="text" name="home" value="<?= h($v['home']) ?>" placeholder="Ex. : 12 rue …, 77130 La Grande-Paroisse" data-ac-input>
      <input type="hidden" name="home_lat" value="<?= h($v['home_lat']) ?>" data-ac-lat>
      <input type="hidden" name="home_lon" value="<?= h($v['home_lon']) ?>" data-ac-lon>
      <small class="muted" style="display:block;font-size:12.5px;margin-top:4px">Sert à masquer votre position aux clients tant que vous êtes près de chez vous. Jamais affichée.</small>
    </div>
    <button class="btn btn-primary btn-block btn-lg" type="submit">Installer</button>
  </form>
</div></div>
<div class="toast" id="toast"></div>
<script src="<?= h(asset('js/admin.js')) ?>"></script>
</body>
</html>
