<?php
/** Relais d'autocomplétion d'adresse (si l'appel direct à l'IGN échoue dans le navigateur). */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
require_admin(true);
json_out(['results' => geocode_search((string)($_GET['q'] ?? ''), 6)]);
