<?php
/** État public d'une intervention (page client, interrogée toutes les 4 s pendant le trajet). */
declare(strict_types=1);
require dirname(__DIR__) . '/inc/bootstrap.php';
if (!is_installed()) json_out(['error' => 'install'], 503);

$iv = get_iv_by_token((string)($_GET['k'] ?? ''));
if (!$iv || $iv['status'] === 'cancelled') json_out(['error' => 'notfound'], 404);
json_out(public_state($iv, (int)($_GET['v'] ?? -1)));
