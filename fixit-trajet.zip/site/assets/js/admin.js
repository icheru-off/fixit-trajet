/* FixIT Suivi — outils communs de l'espace admin */
(function () {
  'use strict';

  function toast(t) {
    var el = document.getElementById('toast');
    if (!el) return;
    el.textContent = t; el.classList.add('on');
    clearTimeout(el.__t); el.__t = setTimeout(function () { el.classList.remove('on'); }, 2200);
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { toast('Copié ✔'); }, fallback);
    }
    fallback();
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
      try { document.execCommand('copy'); toast('Copié ✔'); } catch (e) { toast('Sélectionnez le texte pour le copier'); }
      document.body.removeChild(ta);
    }
    return Promise.resolve();
  }

  function isApple() { return /iPhone|iPad|Macintosh/.test(navigator.userAgent); }

  function openSms(phone, text) {
    if (!phone) { copyText(text); return; }
    // iOS : sms:num&body=…  /  Android : sms:num?body=…
    var sep = isApple() ? '&' : '?';
    location.href = 'sms:+' + phone + sep + 'body=' + encodeURIComponent(text);
  }
  function openWhatsApp(phone, text) {
    window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
  }
  function openMail(email, subject, text) {
    location.href = 'mailto:' + encodeURIComponent(email) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(text);
  }

  // boutons [data-copy]
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]');
    if (b) {
      var src = document.querySelector(b.getAttribute('data-copy'));
      if (src) copyText(src.value || src.textContent);
      return;
    }
    var sh = e.target.closest('[data-share]');
    if (sh) {
      var url = sh.getAttribute('data-share');
      if (navigator.share) navigator.share({ title: 'Suivi de votre intervention FixIT', url: url }).catch(function () {});
      else copyText(url);
    }
  });

  // confirmation des actions sensibles
  document.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  /* ───── Autocomplétion d'adresse (API Géoplateforme IGN, gratuite) ───── */
  var GEO = 'https://data.geopf.fr/geocodage/search';
  function search(q, proxy) {
    var url = GEO + '?limit=6&index=address&q=' + encodeURIComponent(q);
    return fetch(url, { cache: 'no-store' }).then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .then(function (j) {
        return (j.features || []).map(function (f) {
          return { label: f.properties.label, context: f.properties.context || '', lon: f.geometry.coordinates[0], lat: f.geometry.coordinates[1] };
        });
      })
      .catch(function () {
        if (!proxy) return [];
        return fetch(proxy + '?q=' + encodeURIComponent(q), { credentials: 'same-origin' })
          .then(function (r) { return r.ok ? r.json() : { results: [] }; })
          .then(function (j) { return j.results || []; }).catch(function () { return []; });
      });
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-ac]'), function (box) {
    var input = box.querySelector('[data-ac-input]');
    var lat = box.querySelector('[data-ac-lat]'), lon = box.querySelector('[data-ac-lon]'), ok = box.querySelector('[data-ac-ok]');
    var proxy = box.getAttribute('data-proxy');
    var list = document.createElement('div'); list.className = 'ac-list hidden'; box.appendChild(list);
    var badge = document.createElement('span'); badge.className = 'ac-ok'; box.appendChild(badge);
    var timer = null, items = [], sel = -1, seq = 0;
    if (lat.value && lon.value) badge.textContent = '✓ Adresse localisée';

    function close() { list.classList.add('hidden'); sel = -1; }
    function pick(it) {
      input.value = it.label; lat.value = it.lat; lon.value = it.lon; if (ok) ok.value = '1';
      badge.textContent = '✓ Adresse localisée'; close();
    }
    function draw() {
      list.innerHTML = '';
      items.forEach(function (it, i) {
        var b = document.createElement('button'); b.type = 'button'; b.className = i === sel ? 'on' : '';
        b.textContent = it.label;
        var sm = document.createElement('small'); sm.textContent = it.context; b.appendChild(sm);
        b.addEventListener('mousedown', function (ev) { ev.preventDefault(); pick(it); });
        list.appendChild(b);
      });
      list.classList.toggle('hidden', !items.length);
    }
    input.addEventListener('input', function () {
      lat.value = ''; lon.value = ''; if (ok) ok.value = '0'; badge.textContent = '';
      clearTimeout(timer);
      var q = input.value.trim();
      if (q.length < 4) { items = []; draw(); return; }
      timer = setTimeout(function () {
        var my = ++seq;
        search(q, proxy).then(function (res) { if (my === seq) { items = res; sel = -1; draw(); } });
      }, 250);
    });
    input.addEventListener('keydown', function (e) {
      if (list.classList.contains('hidden')) return;
      if (e.key === 'ArrowDown') { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
      else if (e.key === 'Enter' && sel >= 0) { pick(items[sel]); e.preventDefault(); }
      else if (e.key === 'Escape') close();
    });
    input.addEventListener('blur', function () { setTimeout(close, 150); });
  });

  window.FixitAdmin = { toast: toast, copy: copyText, openSms: openSms, openWhatsApp: openWhatsApp, openMail: openMail };
})();
