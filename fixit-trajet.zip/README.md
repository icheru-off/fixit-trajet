# FixIT Trajet & Suivi

- `site/` : site de suivi d'intervention (PHP 8.1+ / SQLite) pour o2switch — espace admin + page client.
- `ios/` : application iPhone **FixIT Trajet** (Swift/SwiftUI, iOS 16+), GPS en arrière-plan + file d'attente hors-ligne.
- `.github/workflows/build-ipa.yml` : compile l'IPA sur un Mac GitHub → branche `resultats-ipa` + onglet Actions › Artifacts.
- `.github/workflows/test-site.yml` : teste le site avec les vrais services (OpenFreeMap, OSRM, IGN) → branche `resultats-tests`.
